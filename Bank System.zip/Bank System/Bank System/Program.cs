﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Business_Logic;
using Entity;
namespace Bank_System
{
    class Program {                                            //class declaration
       
       public static void front()
        {
            int Option;
            //Main Menu
                Console.WriteLine("|-------Bank System-------|");
                Console.WriteLine("|1---Create New Account.  |");
                Console.WriteLine("|2---Account Details.     |");
                Console.WriteLine("|3---Exit                 |");
                Console.WriteLine("|-------------------------|");
                Console.WriteLine("Enter Option:");
                Option = int.Parse(Console.ReadLine());

                switch (Option)
                {
                    case 1:
                        {
                        UserEntries();
                      
                            break;
                        }
                    case 2:
                        {
                        LoginDetail();
                           
                            break;
                        }
                    case 3:
                        {
                            break;
                        }
                    default:
                        {
                            Console.WriteLine("Please Enter valid Option.");
                            break;
                        }
                }
            }
        public static void LoginDetail()
        {
           
            Login login = new Login();
            Console.WriteLine("----Login----");
            Console.WriteLine("Enter Name:");
            login.Name = Console.ReadLine();
            Console.WriteLine("Enter Password:");
            login.password = Console.ReadLine();
            int result=Business.UserLogin(login);
            int checkValue = 0;
            if (result == 1)
            {
                while (checkValue != 5)
                {
                    Console.WriteLine("Select option:");
                    Console.WriteLine("1--To check Balance");
                    Console.WriteLine("2--To check Interest");
                    Console.WriteLine("3--To Add Balance");
                    Console.WriteLine("4--To Withdraw Money");
                    Console.WriteLine("5--To Log Out");
                    Console.WriteLine("Enter Choice:");
                    checkValue = int.Parse(Console.ReadLine());
                    if (checkValue == 1)   //To check Balance
                    {
                        int balance = Business.Balance(login);
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("Your Balance is: " + balance);
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    if (checkValue == 2)   //To Check Interest
                    {
                        string AccountType = Business.Interest(login);
                        if (AccountType == "Saving Account")       //checking saving account
                        {
                            int balance = Business.Balance(login);
                            int Interest = (4 * balance) / 100;
                            Console.WriteLine("Interest: " + Interest);
                        }

                        else if (AccountType == "Current Account")  //checking current account
                        {
                            int balance = Business.Balance(login);
                            int Interest = (1 * balance) / 100;
                            Console.WriteLine("Interest: " + Interest);
                        }
                        else
                        {
                            int balance = Business.Balance(login);
                            Console.WriteLine("Interest: " + balance);
                        }
                    }
                    if (checkValue == 3) // To add Balance
                    {
                        int balance = Business.Balance(login);
                        Console.WriteLine("Please enter an amount which you want to add:");
                        int newAmount = int.Parse(Console.ReadLine());
                        newAmount += balance;
                        int value = Business.Details(login, newAmount);
                        if (newAmount<= 8500 && value==1)
                        {
                              balance = Business.Balance(login);
                                Console.WriteLine("New Balance: " + balance);
                            Console.WriteLine("-------------------------------------------");
                            Console.WriteLine("Your Transaction has been successfully done");
                            Console.WriteLine("Your Current Balance is: " + balance);
                            Console.WriteLine("--------------------------------------------");

                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.DarkRed;
                            Console.WriteLine("--------------------------------------------------");
                            Console.WriteLine("Sorry, You are crossing the Account balance limit i.e 85000");
                            Console.WriteLine("--------------------------------------------------");
                            Console.ForegroundColor = ConsoleColor.White;
                        }
                    }
                    if (checkValue == 4)   //To Withdraw Money
                    {
                        string AccountType = Business.Interest(login);
                        int balance1 = Business.Balance(login);
                        Console.WriteLine("Please enter an amount which you want to withdraw:");
                        int WithdrawAmount = int.Parse(Console.ReadLine());
                        balance1 -= WithdrawAmount;
                        int value = Business.Details(login, balance1);
                        if (balance1 > 1000 && AccountType == "Saving Account" && value==1) //check for invalid transaction
                        {
                           int balance = Business.Balance(login);
                            Console.WriteLine("New Balance: " + value);
                            Console.WriteLine("-------------------------------------------");
                            Console.WriteLine("Your Transaction has been successfully done");
                            Console.WriteLine("Your Current Balance is: " +balance);
                            Console.WriteLine("--------------------------------------------");
                        }
                        else if (balance1 >= 0 && AccountType == "Current Account" && value==1)   //check for invalid transaction
                        {

                            int balance = Business.Balance(login);
                            Console.WriteLine("New Balance: " + value);
                            Console.WriteLine("--------------------------------------------");
                            Console.WriteLine("Your Transaction has been successfully done");
                            Console.WriteLine("Your Current Balance is: " + balance);
                            Console.WriteLine("--------------------------------------------");
                        }
                        else if (balance1>= -10000 && AccountType == "DMAT Account" && value==1)   //check for invalid transaction
                        {
                            int balance = Business.Balance(login);
                            Console.WriteLine("New Balance: " + value);
                            Console.WriteLine("-------------------------------------------");
                            Console.WriteLine("Your Transaction has been successfully done");
                            Console.WriteLine("Your Current Balance is: " +balance);
                            Console.WriteLine("--------------------------------------------");
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.DarkRed;
                            Console.WriteLine("--------------------------------------------------");
                            Console.WriteLine("Sorry, we are not able to process your Transaction");
                            Console.WriteLine("--------------------------------------------------");
                            Console.ForegroundColor = ConsoleColor.White;
                        }
                    }
                }
            }
            else
                LoginDetail();
        }
            public static void UserEntries()
        {

            Customer user = new Customer();
            Console.WriteLine("Enter Account Holder's Name:");
            user.Name = Console.ReadLine();  //Reading customer name
          
            Console.WriteLine("Enter Password:");
            user.password = Console.ReadLine();
            Console.WriteLine("Enter Account Type:");
            Console.WriteLine("1---Savings");
            Console.WriteLine("2---Current");
            Console.WriteLine("3---DMAT");
            Console.WriteLine("Enter Choice:");
            int Choice = int.Parse(Console.ReadLine()); //reading account type

            if (Choice == 1)
            {//assigning details of a particular customer in Savings Account


                user.Deposit = 1000;
                user.AccountType = "Saving Account";

            }
            else if (Choice == 2)
            {//Current Account
                user.Deposit = 0;
                user.AccountType = "Current Account";
            }
            else if (Choice == 3)
            {//DMAT Account

                user.Deposit = -10000;
                user.AccountType = "DMAT Account";
          }
                     Business.NewAccount(user);
            front();
        }
       public static void Main(string[] args)
        {
            var _continue = true;
            while (_continue)
            {
                front();
                Console.WriteLine("Do you want to Exit? (y/n)");
                if (Console.ReadLine() == "y")
                    _continue = false;
            }
        }
    }
}
