﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class Customer
    {
        public int Deposit;
        public string AccountType;
        public string Name;
        public string password;
    }
}
