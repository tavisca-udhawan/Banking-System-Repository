﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;
using Entity;
namespace Business_Logic
{
    public class Business
    {
      
        public static string Interest(Login login)
        {
            string AccountType = Connections.Interest(login);
            return AccountType;
        }
        public static int Balance(Login login)
        {
            int balance=Connections.Balance(login);
            return balance;
        }
            public static int NewAccount(Customer user)
        {
            Connections.CreateNewAccount(user);
            return 1;
        }
        public static int UserLogin(Login login)
        {
           int result= Connections.LoginData(login);
            if (result == 1)
                return 1;
            else
                return 0;
        }
            public static int Details(Login login,int data)
        {
          
            Connections.AccountDetails(login,data);
            return 1;
        }

      

        
    }
}
