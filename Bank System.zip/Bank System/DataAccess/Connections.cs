﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entity;
namespace DataAccess
{
    public class Connections
    {
       static string value1 = "";
        static string value2 = "";
 enum Accounts { Salary = 0, Current, DMAT };   //enums
        public static string Interest(Login login)
        {
            string AccType = "";
            SqlConnection connection = new SqlConnection("Data Source=TAVDESK087;Initial Catalog=DBBankingSystem;Integrated Security=True");
            connection.Open();
            SqlCommand command = new SqlCommand("Login_Check", connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@Name", login.Name);
            command.Parameters.AddWithValue("@Password", login.password);
            SqlDataReader reader = command.ExecuteReader();
            int flag = 0;
            while (reader.Read())
            {
                if (login.Name == reader["Name"].ToString() && login.password == reader["Password"].ToString())
                {
                   AccType = reader["AccountType"].ToString();
                    flag = 1;
                    break;
                }
            }
            reader.Close();
            connection.Close();
            return AccType;
        }
        
        public static int Balance(Login login)
        {
            string balance = "";
            SqlConnection connection = new SqlConnection("Data Source=TAVDESK087;Initial Catalog=DBBankingSystem;Integrated Security=True");
            connection.Open();
            SqlCommand command = new SqlCommand("Login_Check", connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@Name", login.Name);
            command.Parameters.AddWithValue("@Password", login.password);
            SqlDataReader reader = command.ExecuteReader();
            int flag = 0;
            while (reader.Read())
            {
                if (login.Name == reader["Name"].ToString() && login.password == reader["Password"].ToString())
                {
                    balance = reader["Balance"].ToString();
                    flag = 1;
                    break;
                }
            }
            reader.Close();
            connection.Close();
            return int.Parse(balance);
        }
        public static int LoginData(Login login)
        {
            value1 = login.Name;
            value2 = login.password;
            string AccountNumber="";
            string UserName="";
            string balance="";
            string account="";
    SqlConnection connection = new SqlConnection("Data Source=TAVDESK087;Initial Catalog=DBBankingSystem;Integrated Security=True");
            connection.Open();
            SqlCommand command = new SqlCommand("Login_Check", connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@Name",login.Name);
            command.Parameters.AddWithValue("@Password", login.password);
            SqlDataReader reader = command.ExecuteReader();
            int flag = 0;
            while(reader.Read())
            {
                if (login.Name== reader["Name"].ToString() && login.password== reader["Password"].ToString() )
                {
                    AccountNumber = reader["AccountID"].ToString();
                    UserName = reader["Name"].ToString();
                    balance = reader["Balance"].ToString();
                    account = reader["AccountType"].ToString();

                    flag = 1;
                    break;
                }
            }
            reader.Close();
            connection.Close();
            if (flag == 1)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("You are logging in....");
                Console.WriteLine("-----------------------------------------------------------");
                Console.WriteLine("Account Number: "+AccountNumber+"     Name: "+UserName);
                Console.WriteLine("Balance: " + balance + "          Account: " + account);
                Console.WriteLine("-----------------------------------------------------------");
                Console.ForegroundColor = ConsoleColor.White;
                return 1;
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Login failed.....");
                Console.ForegroundColor = ConsoleColor.White;

                return 0;
            }
        }
        public static void AccountDetails(Login login,int Data)                     //static functions
        {
            SqlConnection Connection = new SqlConnection("Data Source=TAVDESK087;Initial Catalog=DBBankingSystem;Integrated Security=True");
            Connection.Open();
            string Com = "update CustomerDetails set Balance= '" + Data + "' where Name=@AName";
            SqlCommand Command = new SqlCommand(Com, Connection);
            Command.Parameters.AddWithValue("@AName", login.Name);
            Command.ExecuteNonQuery();
            
            Connection.Close();
        }
        public static int CreateNewAccount(Customer user)
        {
            SqlConnection connection = new SqlConnection("Data Source=TAVDESK087;Initial Catalog=DBBankingSystem;Integrated Security=True");
          connection.Open();
            SqlCommand command = new SqlCommand("AddCustomers", connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@Name",user.Name);
            command.Parameters.AddWithValue("@AccountType",user.AccountType);
            command.Parameters.AddWithValue("@Balance",user.Deposit);
            command.Parameters.AddWithValue("@Password",user.password);
            int result=command.ExecuteNonQuery();
            if (result == 1)
            {
                connection.Close();
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Data Successfully added");
                Console.ForegroundColor = ConsoleColor.White;
                return 1;
            }
            else
            return 0;
        }
    }
}
